<div class="fullwidth-sidebar-container">
    <div class="sidebar bottom-sidebar"></div>
</div>
<footer id="footer" class="site-footer" role="contentinfo">
    <div class="copyright">
        <div class="container">
            <p class="copyright-text"> Copyright &copy; 2020 <a href='Kebun Digital' target='_blank' title='Directory Starter'> Kebun Digital</a>.</p>
        </div>
    </div>
</footer><?php /**PATH D:\cari-tempats\resources\views/partials/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="content-box content-single">
                <article class="post-180 gd_place type-gd_place status-publish hentry gd_placecategory-hotels">
                    <header>
                        <h1 class="entry-title"><?php echo e($shop->name); ?></h1></header>
                    <div class="entry-content entry-summary">
                        <?php if($shop->photos->count()): ?>
                            <div class="geodir-post-slider center-gallery">
                                <div class="bxslider">
                                    <?php $__currentLoopData = $shop->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><img src="<?php echo e($photo->url); ?>"></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($shop->categories->count()): ?>
                            <div class="geodir-single-taxonomies-container">
                                <p class="geodir_post_taxomomies clearfix"> 
                                    <span class="geodir-category">
                                        Categories: 
                                        <?php $__currentLoopData = $shop->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('home')); ?>?category=<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a><?php echo e(!$loop->last ? ',' : ''); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span>
                                </p>
                            </div>
                        <?php endif; ?>
                        <div class="geodir-single-tabs-container">
                            <div class="geodir-tabs" id="gd-tabs">
                                <dl class="geodir-tab-head"><dt></dt>
                                    <dd class="geodir-tab-active"><a data-tab="#post_content" data-status="enable"><i class="fas fa-home" aria-hidden="true"></i>About</a></dd><dt></dt>
                                    <?php if($shop->photos->count()): ?>
                                        <dd class=""><a data-tab="#post_images" data-status="enable"><i class="fas fa-image" aria-hidden="true"></i>Photos</a></dd><dt></dt>
                                    <?php endif; ?>
                                    <?php if($shop->latitude && $shop->longitude): ?>
                                        <dd class=""><a data-tab="#post_map" data-status="enable"><i class="fas fa-globe-americas" aria-hidden="true"></i>Map</a></dd><dt></dt>
                                    <?php endif; ?>
                                    <?php if($shop->days->count()): ?>
                                        <dd class=""><a data-tab="#working_hours" data-status="enable"><i class="fas fa-clock" aria-hidden="true"></i>Working Hours</a></dd>
                                    <?php endif; ?>
                                </dl>
                                <ul class="geodir-tabs-content geodir-entry-content " style="z-index: 0; position: relative;">
                                    <li id="post_contentTab" style="display: none;"><span id="post_content"></span>
                                        <div id="geodir-tab-content-post_content" class="hash-offset"></div>
                                        <div class="geodir-post-meta-container">
                                            <div class="geodir_post_meta  geodir-field-post_content">
                                                
                                                
                                                
                                                <p><?php echo  $shop->description ;?></p>
                                                <br>
                                                <p>Alamat: <?php echo e($shop->address); ?></p>
                                                <?php if($shop->days->count()): ?>
                                                    <?php if($shop->working_hours->currentOpenRange(now())): ?>
                                                        <p>Shop is open and will close at <?php echo e($shop->working_hours->currentOpenRange(now())->end()); ?>.</p>
                                                    <?php else: ?>
                                                    <br>
                                                        <p>Place is closed since <?php echo e($shop->working_hours->previousClose(now())->format('l H:i')); ?>

                                                            and will re-open at <?php echo e($shop->working_hours->nextOpen(now())->format('l H:i')); ?></p>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <p></p>
                                            </div>
                                        </div>
                                    </li>
                                    <?php if($shop->photos->count()): ?>
                                        <li id="post_imagesTab" style="display: none;"><span id="post_images"></span>
                                            <div id="geodir-tab-content-post_images" class="hash-offset"></div>
                                            <div class="geodir-post-slider">
                                                <div class="geodir-image-container geodir-image-sizes-medium_large ">
                                                    <div id="geodir_images_5de6cafacbba5_180" class="geodir-image-wrapper" data-controlnav="1" data-slideshow="1">
                                                        <ul class="geodir-gallery geodir-images clearfix">
                                                            <?php $__currentLoopData = $shop->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li>
                                                                    <a href="<?php echo e($photo->getUrl()); ?>" class="geodir-lightbox-image" target="_blank"><img src="<?php echo e($photo->getUrl('thumb')); ?>" width="1440" height="960"><i class="fas fa-search-plus" aria-hidden="true"></i></a>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($shop->latitude && $shop->longitude): ?>
                                        <li id="post_mapTab" style="display: none;">
                                            <div id="map-canvas" style="height: 425px; width: 100%; position: relative; overflow: hidden;">
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($shop->days->count()): ?>
                                        <li id="working_hoursTab" style="display: none;">
                                            <?php $__currentLoopData = $shop->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e(ucfirst($day->name)); ?>: from <?php echo e($day->pivot->from_hours); ?>:<?php echo e($day->pivot->from_minutes); ?> to <?php echo e($day->pivot->to_hours); ?>:<?php echo e($day->pivot->to_minutes); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="geodir-single-taxonomies-container">
                            <div class="geodir-pos_navigation clearfix">
                                <div class="geodir-post_left">
                                    <a href="<?php echo e(url()->previous()); ?>" rel="prev">Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <footer class="entry-footer"></footer>
                </article>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
<style>
@media  only screen and (min-width: 675px) {
    .center-gallery {
        width: 50%;
        margin: auto;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>
<script type="text/javascript">
if (window.location.hash && window.location.hash.indexOf('&') === -1 && jQuery(window.location.hash + 'Tab').length) {
    hashVal = window.location.hash;
} else {
    hashVal = jQuery('dl.geodir-tab-head dd.geodir-tab-active').find('a').attr('data-tab');
}
openTab(hashVal);

jQuery('dl.geodir-tab-head dd a').click(function() {
    openTab(jQuery(this).data('tab'))
});

function openTab(hashVal)
{
    jQuery('dl.geodir-tab-head dd').each(function() {
        var tab = '';
        tab = jQuery(this).find('a').attr('data-tab');
        jQuery(this).removeClass('geodir-tab-active');
        if (hashVal != tab) {
            jQuery(tab + 'Tab').hide();
        }
    });
    jQuery('a[data-tab="'+hashVal+'"]').parent().addClass('geodir-tab-active');
    jQuery(hashVal + 'Tab').show();
}

$(function(){
    $('.bxslider').bxSlider({
        mode: 'fade',
        slideWidth: 600
    });
});
</script>
<?php if($shop->latitude && $shop->longitude): ?>
  <script src="/js/mapInput.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAp8pJH-SJZwtlJUjoj-xJripfDtl_0EW0&libraries=places&callback=initialize&language=en&region=ID" async defer></script>
    <script defer>
        function initialize() {
            var latLng = new google.maps.LatLng(<?php echo e($shop->latitude); ?>, <?php echo e($shop->longitude); ?>);
            var mapOptions = {
                zoom: 20,
                minZoom: 6,
                maxZoom: 17,
                zoomControl:true,
                zoomControlOptions: {
                    style:google.maps.ZoomControlStyle.DEFAULT
                },
                center: latLng,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                scrollwheel: false,
                panControl:false,
                mapTypeControl:false,
                scaleControl:false,
                overviewMapControl:false,
                rotateControl:false
            }
            var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
            var image = new google.maps.MarkerImage("<?php echo e(asset('assets/images/pin.png')); ?>", null, null, null, new google.maps.Size(40,52));

            var content = `
            <div class="gd-bubble" style="">
                <div class="gd-bubble-inside">
                    <div class="geodir-bubble_desc">
                    <div class="geodir-bubble_image">
                        <div class="geodir-post-slider">
                            <div class="geodir-image-container geodir-image-sizes-medium_large ">
                                <div id="geodir_images_5de53f2a45254_189" class="geodir-image-wrapper" data-controlnav="1">
                                    <ul class="geodir-post-image geodir-images clearfix">
                                        <li>
                                            <div class="geodir-post-title">
                                                <h4 class="geodir-entry-title">
                                                    <a href="<?php echo e(route('shop', $shop->id)); ?>" title="View: <?php echo e($shop->name); ?>"><?php echo e($shop->name); ?></a>
                                                </h4>
                                            </div>
                                            <a href="<?php echo e(route('shop', $shop->id)); ?>"><img src="<?php echo e($shop->thumbnail); ?>" alt="<?php echo e($shop->name); ?>" class="align size-medium_large" width="1400" height="930"></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="geodir-bubble-meta-side">
                    <div class="geodir-output-location">
                    <div class="geodir-output-location geodir-output-location-mapbubble">
                        <div class="geodir_post_meta  geodir-field-post_title"><span class="geodir_post_meta_icon geodir-i-text">
                            <i class="fas fa-minus" aria-hidden="true"></i>
                            <span class="geodir_post_meta_title">Place Title: </span></span><?php echo e($shop->name); ?></div>
                        <div class="geodir_post_meta  geodir-field-address" itemscope="" itemtype="http://schema.org/PostalAddress">
                            <span class="geodir_post_meta_icon geodir-i-address"><i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                            <span class="geodir_post_meta_title">Address: </span></span><span itemprop="streetAddress"><?php echo e($shop->address); ?></span>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            </div>
            </div>`;
            var marker = new google.maps.Marker({
                position: latLng,
                icon:image,
                map: map,
                title: '<?php echo e($shop->name); ?>'
            });
            var infowindow = new google.maps.InfoWindow();
            google.maps.event.addListener(marker, 'click', (function (marker) {
                return function () {
                    infowindow.setContent(content)
                    infowindow.open(map, marker);
                }
            })(marker));
        }
        google.maps.event.addDomListener(window, 'load', initialize);
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\cari-tempats\resources\views/shop.blade.php ENDPATH**/ ?>
<div class="fullwidth-sidebar-container">
    <div class="sidebar top-sidebar">
        <div id="map-canvas" style="height: 250px; width: 100%; position: relative; overflow: hidden;">
        </div>
    </div>
</div><?php /**PATH D:\cari-tempats\resources\views/partials/map.blade.php ENDPATH**/ ?>